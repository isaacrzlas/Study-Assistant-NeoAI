const $ = (selector, scope = document) => scope.querySelector(selector);
const $$ = (selector, scope = document) => [...scope.querySelectorAll(selector)];

const scrollProgress = $("#scrollProgress");
const sections = $$(".section[id], .hero[id]");
const navItems = $$(".nav-item");
const toast = $("#toast");

let quiz = [];

const summaryContent = {
  beginner: [
    "Upload notes to generate beginner-friendly concepts.",
    "Upload notes to extract formulas.",
    "Upload notes to create review cards."
  ],
  detailed: [
    "Upload notes to generate detailed concepts.",
    "Upload notes to extract detailed formula context.",
    "Upload notes to create detailed review cards."
  ],
  exam: [
    "Upload notes to generate exam-focused concepts.",
    "Upload notes to extract exam formulas.",
    "Upload notes to create exam review cards."
  ],
  quick: [
    "Upload notes to generate quick concepts.",
    "Upload notes to extract quick formulas.",
    "Upload notes to create quick review cards."
  ]
};

let quizIndex = 0;
let selectedAnswer = null;
let uploadedSources = [];
let apiKey = localStorage.getItem("astraGeminiKey") || "";
let apiModel = localStorage.getItem("astraGeminiModel") || "gemini-2.5-flash";
let currentUser = JSON.parse(localStorage.getItem("astraCurrentUser") || "null");
let studyArtifacts = null;

function updateScrollProgress() {
  const max = document.documentElement.scrollHeight - innerHeight;
  scrollProgress.style.width = `${Math.max(0, scrollY / max) * 100}%`;
}

function setActiveNav() {
  const current = sections
    .map(section => ({ id: section.id, top: section.getBoundingClientRect().top }))
    .filter(item => item.top < innerHeight * 0.45)
    .pop();

  if (!current) return;
  navItems.forEach(item => item.classList.toggle("active", item.dataset.section === current.id));
}

function revealOnScroll() {
  $$(".reveal").forEach((element, index) => {
    const rect = element.getBoundingClientRect();
    const progress = Math.min(1, Math.max(0, 1 - rect.top / innerHeight));
    if (rect.top < innerHeight * 0.88) {
      element.style.transitionDelay = `${Math.min(index * 45, 180)}ms`;
      element.classList.add("visible");
    }
    element.style.setProperty("--scroll-lift", `${(progress - 0.5) * -22}px`);
    element.style.setProperty("--scroll-fade", `${0.72 + progress * 0.28}`);
  });

  $$(".widget, .panel, .summary-card").forEach((element, index) => {
    const rect = element.getBoundingClientRect();
    const drift = Math.min(18, Math.max(-18, (rect.top - innerHeight * 0.5) * -0.018));
    element.style.setProperty("--drift", `${drift + (index % 3) * 1.5}px`);
  });
}

function showToast(text) {
  toast.textContent = text;
  toast.classList.add("show");
  setTimeout(() => toast.classList.remove("show"), 2800);
}

function renderQuiz() {
  $("#questionTotal").textContent = quiz.length;
  if (!quiz.length) {
    $("#questionNumber").textContent = "0";
    $("#questionText").textContent = "Upload notes to generate a quiz.";
    $("#quizProgress").style.width = "0%";
    $("#answers").innerHTML = "";
    return;
  }
  const item = quiz[quizIndex];
  selectedAnswer = null;
  $("#questionNumber").textContent = quizIndex + 1;
  $("#questionText").textContent = item.q;
  $("#quizProgress").style.width = `${((quizIndex + 1) / quiz.length) * 100}%`;
  $("#answers").innerHTML = item.options
    .map((option, index) => `<button data-index="${index}"><span>${option}</span><b></b></button>`)
    .join("");
}

function selectAnswer(button) {
  if (selectedAnswer !== null) return;
  selectedAnswer = Number(button.dataset.index);
  const correct = quiz[quizIndex].answer;
  $$("#answers button").forEach(answer => {
    const index = Number(answer.dataset.index);
    if (index === correct) {
      answer.classList.add("correct");
      $("b", answer).textContent = "Correct";
    } else if (index === selectedAnswer) {
      answer.classList.add("wrong");
      $("b", answer).textContent = "Review";
    }
  });
}

function addMessage(role, html) {
  const message = document.createElement("div");
  message.className = `message ${role}`;
  message.innerHTML = html;
  $("#messages").appendChild(message);
  $("#messages").scrollTop = $("#messages").scrollHeight;
  return message;
}

function escapeHtml(value) {
  return String(value).replace(/[<>&"]/g, char => ({ "<": "&lt;", ">": "&gt;", "&": "&amp;", "\"": "&quot;" })[char]);
}

function markdownToHtml(value) {
  return escapeHtml(value)
    .replace(/```([\s\S]*?)```/g, "<pre><code>$1</code></pre>")
    .replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>")
    .replace(/\n- (.*?)(?=\n|$)/g, "<li>$1</li>")
    .replace(/(<li>.*<\/li>)/gs, "<ul>$1</ul>")
    .replace(/\n{2,}/g, "</p><p>")
    .replace(/\n/g, "<br>");
}

function isGreeting(prompt) {
  return /^(hi|hello|hey|yo|sup|gm|good morning|good evening)\b[!.\s]*$/i.test(prompt.trim());
}

function fileToBase64(file) {
  return new Promise(resolve => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result || "").split(",")[1] || "");
    reader.onerror = () => resolve("");
    reader.readAsDataURL(file);
  });
}

function wantsDetailedAnswer(prompt) {
  return /\b(detail|detailed|deep|full|long|step[- ]?by[- ]?step|explain thoroughly|complete|comprehensive|in depth)\b/i.test(prompt);
}

function wantsBriefAnswer(prompt) {
  return /\b(short|brief|quick|concise|summarize simply|tl;?dr)\b/i.test(prompt);
}

function profileKey() {
  return currentUser ? `astraWorkspace:${currentUser.email}` : null;
}

function saveWorkspace() {
  const key = profileKey();
  if (!key) return;
  const lightweightSources = uploadedSources.map(source => ({
    name: source.name,
    type: source.type,
    text: source.text,
    hasBinary: Boolean(source.base64)
  }));
  localStorage.setItem(key, JSON.stringify({
    apiModel,
    studyArtifacts,
    uploadedSources: lightweightSources,
    savedAt: new Date().toISOString()
  }));
}

function loadWorkspace() {
  const key = profileKey();
  if (!key) return;
  const saved = JSON.parse(localStorage.getItem(key) || "null");
  if (!saved) return;
  apiModel = saved.apiModel || apiModel;
  studyArtifacts = saved.studyArtifacts || null;
  uploadedSources = (saved.uploadedSources || []).map(source => ({ ...source, base64: "" }));
  if (uploadedSources.length) {
    $("#fileStack").classList.remove("empty");
    $("#fileStack").innerHTML = uploadedSources.map(source => `<div class="file-chip ${source.text ? "" : "unreadable"}"><span>${escapeHtml(source.name.split(".").pop().slice(0, 3).toUpperCase())}</span>${escapeHtml(source.name)}<small>${source.text ? "restored text" : "binary not restored"}</small></div>`).join("");
    hydrateWorkspaceFromUploads();
  }
  if (studyArtifacts) applyStudyArtifacts(studyArtifacts);
}

function setCurrentUser(user) {
  currentUser = user;
  localStorage.setItem("astraCurrentUser", JSON.stringify(user));
  $("#authScreen").classList.add("hidden");
  $("#profilePill").classList.remove("hidden");
  $("#profileInitial").textContent = (user.name || user.email || "U").charAt(0).toUpperCase();
  $("#profileName").textContent = user.name || user.email;
  loadWorkspace();
}

function decodeJwtPayload(token) {
  const payload = token.split(".")[1];
  return JSON.parse(atob(payload.replace(/-/g, "+").replace(/_/g, "/")));
}

function loadGoogleScript() {
  return new Promise((resolve, reject) => {
    if (window.google?.accounts?.id) {
      resolve();
      return;
    }
    const script = document.createElement("script");
    script.src = "https://accounts.google.com/gsi/client";
    script.async = true;
    script.defer = true;
    script.onload = resolve;
    script.onerror = reject;
    document.head.appendChild(script);
  });
}

function getUploadedSourceNames() {
  return uploadedSources.map(source => source.name);
}

function getReadableSources() {
  return uploadedSources.filter(source => source.text.trim().length > 0);
}

function tokenize(value) {
  return value
    .toLowerCase()
    .replace(/[^a-z0-9\s]/g, " ")
    .split(/\s+/)
    .filter(word => word.length > 2);
}

function chunkText(text, size = 620) {
  const normalized = text.replace(/\s+/g, " ").trim();
  if (!normalized) return [];
  const chunks = [];
  for (let index = 0; index < normalized.length; index += size) {
    chunks.push(normalized.slice(index, index + size));
  }
  return chunks;
}

function findRelevantChunks(prompt) {
  const terms = new Set(tokenize(prompt));
  const chunks = getReadableSources().flatMap(source =>
    chunkText(source.text).map(chunk => ({ source: source.name, chunk }))
  );

  return chunks
    .map(item => {
      const words = tokenize(item.chunk);
      const score = words.reduce((total, word) => total + (terms.has(word) ? 1 : 0), 0);
      return { ...item, score };
    })
    .sort((a, b) => b.score - a.score)
    .slice(0, 3)
    .filter((item, index) => item.score > 0 || index === 0);
}

function sentenceFromChunks(chunks) {
  return chunks
    .map(item => item.chunk.split(/(?<=[.!?])\s+/).find(sentence => sentence.length > 45) || item.chunk)
    .map(sentence => escapeHtml(sentence.slice(0, 260)))
    .join(" ");
}

function uploadedContextNotice() {
  const readable = getReadableSources();
  const unreadable = uploadedSources.filter(source => !source.text.trim());
  if (!uploadedSources.length) {
    return "Upload a text-based note first and I will ground answers in it.";
  }
  if (!readable.length) {
    return `I can see ${uploadedSources.length} uploaded file${uploadedSources.length > 1 ? "s" : ""}, but I could not extract readable text from them in the browser. Text files work best; simple PDFs may work, while images and Word files need backend OCR/parsing.`;
  }
  if (unreadable.length) {
    return `Grounded in ${readable.map(source => `<strong>${escapeHtml(source.name)}</strong>`).join(", ")}. ${unreadable.length} file${unreadable.length > 1 ? "s were" : " was"} uploaded but did not expose readable text in the browser.`;
  }
  return `Grounded in ${readable.map(source => `<strong>${escapeHtml(source.name)}</strong>`).join(", ")}.`;
}

function inferTopic(prompt) {
  const cleaned = prompt
    .toLowerCase()
    .replace(/^(explain|summarize|generate|teach|what are|what is|how do|how does|please|can you|tell me about)\s+/i, "")
    .replace(/[?!.]/g, "")
    .trim();

  if (cleaned.includes("formula")) return "the formulas in your notes";
  if (cleaned.includes("exam")) return "exam revision";
  if (cleaned.includes("quiz")) return "quiz practice";
  if (cleaned.includes("plan")) return "your study plan";
  return cleaned || "your uploaded material";
}

function buildAiResponse(prompt) {
  const text = prompt.toLowerCase();
  const safePrompt = escapeHtml(prompt);
  const topic = escapeHtml(inferTopic(prompt));
  const contextLine = uploadedContextNotice();
  const matches = findRelevantChunks(prompt);
  const evidence = matches.length ? sentenceFromChunks(matches) : "";
  const citations = matches.length
    ? `<p class="source-line">Best match: ${matches.map(match => escapeHtml(match.source)).join(", ")}</p>`
    : "";

  if (isGreeting(prompt)) {
    return `<strong>Hey.</strong><p>${uploadedSources.length ? "Ask me anything about your upload." : "Upload a file and I will help with it."}</p>`;
  }

  if (text.includes("summar") || text.includes("chapter")) {
    if (evidence) {
      return `<strong>Summary from your upload</strong><p>${contextLine}</p>${citations}<ul><li><b>Main idea:</b> ${evidence}</li><li><b>Revision focus:</b> turn the densest paragraph into 3 recall questions.</li><li><b>Next step:</b> ask for "exam ready" if you want this compressed into a revision sheet.</li></ul>`;
    }
    return `<strong>Summary needs readable notes</strong><p>${contextLine}</p>`;
  }

  if (text.includes("formula") || text.includes("equation")) {
    const formulaLines = getReadableSources()
      .flatMap(source => source.text.split(/\r?\n/).filter(line => /[=+\-*/^]|formula|equation|derive|where/i.test(line)).slice(0, 8))
      .slice(0, 8);
    if (formulaLines.length) {
      return `<strong>Formula-like lines found</strong><p>${contextLine}</p><pre><code>${escapeHtml(formulaLines.join("\n"))}</code></pre><p>Check the surrounding condition before applying any formula.</p>`;
    }
    return `<strong>No formulas detected yet</strong><p>${contextLine}</p><p>I did not find equation-style lines in the readable upload. Try asking about a specific term from the file.</p>`;
  }

  if (text.includes("exam") || text.includes("likely question")) {
    const basis = evidence || `the readable parts of ${topic}`;
    return `<strong>Likely exam questions from your notes</strong><p>${contextLine}</p>${citations}<ol><li>Explain this idea in simple terms: ${basis.slice(0, 180)}</li><li>List the key terms and show how they connect.</li><li>Create one applied example based on the uploaded material.</li><li>Compare the most similar concepts and name the common mistake.</li></ol>`;
  }

  if (text.includes("quiz") || text.includes("mcq") || text.includes("flashcard")) {
    const basis = evidence || "the strongest paragraph in the uploaded file";
    return `<strong>Practice set generated from the upload</strong><p>${contextLine}</p>${citations}<ul><li><b>MCQ:</b> Which statement best matches this note: "${basis.slice(0, 160)}"?</li><li><b>True/False:</b> The supporting detail changes the meaning of the main concept.</li><li><b>Flashcard:</b> Front: define the concept. Back: cite the exact line from the note.</li></ul>`;
  }

  if (text.includes("explain") || text.includes("simple") || text.includes("teach") || text.includes("step")) {
    if (evidence) {
      return `<strong>Explained from your notes</strong><p>${contextLine}</p>${citations}<ol><li><b>Start here:</b> ${evidence.slice(0, 220)}</li><li><b>In simpler words:</b> identify the main claim, then ask what example or condition proves it.</li><li><b>Check yourself:</b> explain it back without using the file's wording.</li></ol>`;
    }
    return `<strong>Step-by-step mode</strong><p>${contextLine}</p>`;
  }

  if (text.includes("weak") || text.includes("mistake") || text.includes("score")) {
    return `<strong>Weak-topic diagnosis</strong><p>Your tracker should prioritize ${topic} if it shows repeated mistakes, skipped questions, or slow answers.</p><ul><li>Redo missed questions without notes.</li><li>Tag the exact step that failed: concept, formula, substitution, or arithmetic.</li><li>Schedule the next review within 24 hours.</li></ul>`;
  }

  if (text.includes("plan") || text.includes("schedule") || text.includes("hours") || text.includes("exam date")) {
    return `<strong>Adaptive study plan</strong><p>For ${topic}, use a three-block plan:</p><ul><li><b>Block 1:</b> 25 minutes concept repair.</li><li><b>Block 2:</b> 20 minutes exam questions.</li><li><b>Block 3:</b> 10 minutes flashcard recall.</li></ul><p>If you miss a block, move practice first and shorten rereading.</p>`;
  }

  if (text.includes("code") || text.includes("function") || text.includes("bug")) {
    return `<strong>Coding doubt mode</strong><p>I would debug <em>${safePrompt}</em> by checking input, expected output, state changes, and edge cases.</p><pre><code>// Study pattern
trace(input)
compare(expected, actual)
fix smallest failing step</code></pre>`;
  }

  if (evidence) {
    return `<strong>Answer from your uploaded file</strong><p>${contextLine}</p>${citations}<p>${evidence}</p><ul><li><b>What to remember:</b> focus on the relationship between the terms in that passage.</li><li><b>Study move:</b> ask me to turn this answer into flashcards or exam questions.</li></ul>`;
  }

  return `<strong>I need readable uploaded content for that.</strong><p>${contextLine}</p><p>You asked: <em>${safePrompt}</em></p><p>Try uploading a .txt, .md, .csv, or .json file, then ask about a phrase that appears in it.</p>`;
}

async function callGemini(prompt) {
  if (!apiKey) return null;
  if (isGreeting(prompt)) {
    return "Hey. Upload notes or ask me what to summarize, quiz, or explain.";
  }
  if (!uploadedSources.length) {
    return "Hey. Upload a file first, then I can answer from it.";
  }

  const fileParts = uploadedSources.slice(0, 4).map(source => {
    if (source.base64 && source.type) {
      return { inline_data: { mime_type: source.type, data: source.base64 } };
    }
    if (source.text) {
      return { text: `File: ${source.name}\n\n${source.text.slice(0, 26000)}` };
    }
    return null;
  }).filter(Boolean);

  const instruction = [
    "You are Astra, an AI study assistant.",
    "Answer ONLY from the uploaded file content unless the user asks for general study advice.",
    "If the file is unreadable or the answer is not in the material, say that clearly.",
    "Do not output PDF metadata as the answer.",
    wantsDetailedAnswer(prompt)
      ? "The user asked for detail. Give a thorough structured answer with headings, examples, and useful explanation."
      : wantsBriefAnswer(prompt)
        ? "The user asked for brevity. Keep it short."
        : "Give a natural AI-chat answer: enough detail to be useful, usually 2-5 paragraphs or bullets.",
    "If the user only greets you, reply in one short sentence.",
    "For summaries, produce clean student-friendly notes.",
    "For questions, cite the source filename and explain directly."
  ].join(" ");

  const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(apiModel)}:generateContent?key=${encodeURIComponent(apiKey)}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      contents: [{
        role: "user",
        parts: [
          { text: instruction },
          { text: `User question: ${prompt}` },
          ...fileParts
        ]
      }],
      generationConfig: {
        temperature: 0.25,
        maxOutputTokens: wantsDetailedAnswer(prompt) ? 1600 : wantsBriefAnswer(prompt) ? 260 : 760
      }
    })
  });

  const data = await response.json();
  if (!response.ok) {
    const message = data?.error?.message || "Gemini request failed.";
    throw new Error(message);
  }
  return data?.candidates?.[0]?.content?.parts?.map(part => part.text || "").join("\n").trim() || "I could not produce an answer from the uploaded file.";
}

async function requestGeminiJson(instruction, maxOutputTokens = 1800) {
  if (!apiKey || !uploadedSources.length) return null;
  const fileParts = uploadedSources.slice(0, 4).map(source => {
    if (source.base64 && source.type) return { inline_data: { mime_type: source.type, data: source.base64 } };
    if (source.text) return { text: `File: ${source.name}\n\n${source.text.slice(0, 26000)}` };
    return null;
  }).filter(Boolean);

  const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(apiModel)}:generateContent?key=${encodeURIComponent(apiKey)}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      contents: [{
        role: "user",
        parts: [
          { text: instruction },
          ...fileParts
        ]
      }],
      generationConfig: {
        temperature: 0.2,
        maxOutputTokens
      }
    })
  });

  const data = await response.json();
  if (!response.ok) throw new Error(data?.error?.message || "Gemini artifact generation failed.");
  const text = data?.candidates?.[0]?.content?.parts?.map(part => part.text || "").join("\n").trim() || "{}";
  const clean = text
    .replace(/^```json\s*/i, "")
    .replace(/^```\s*/i, "")
    .replace(/```$/i, "")
    .trim();
  const jsonStart = clean.indexOf("{");
  const jsonEnd = clean.lastIndexOf("}");
  if (jsonStart === -1 || jsonEnd === -1) throw new Error("Gemini did not return valid JSON for the study set.");
  return JSON.parse(clean.slice(jsonStart, jsonEnd + 1));
}

function applyStudyArtifacts(artifacts) {
  if (!artifacts) return;
  studyArtifacts = artifacts;
  const summaries = artifacts.summaries || {};
  const summaryCards = $$(".summary-card p");
  summaryCards[0].textContent = (summaries.keyConcepts || []).join(" ") || "No key concepts generated yet.";
  summaryCards[1].textContent = (summaries.formulas || []).join(" ") || "No formulas detected.";
  summaryCards[2].textContent = (artifacts.flashcards || []).slice(0, 3).map(card => `Q: ${card.front} A: ${card.back}`).join(" | ") || "No review cards generated.";

  quiz = (artifacts.quiz || []).slice(0, 8).map(item => ({
    q: item.question || item.q || "Question",
    options: (item.options || []).slice(0, 4),
    answer: Math.max(0, Number(item.answerIndex ?? item.answer ?? 0))
  })).filter(item => item.options.length >= 2);
  quizIndex = 0;
  renderQuiz();

  const firstCard = (artifacts.flashcards || [])[0];
  $("#flashDue").textContent = firstCard ? "AI generated" : "Waiting";
  $("#flashFront").textContent = firstCard?.front || "No AI flashcards generated yet.";
  $("#flashBack").textContent = firstCard?.back || "Generate a study set after upload.";

  const topics = artifacts.weakTopics || [];
  $("#topicList").innerHTML = topics.length
    ? topics.slice(0, 4).map((topic, index) => `<button><span style="--w:${Math.max(34, 82 - index * 12)}%"></span> ${escapeHtml(topic)} <b>${Math.max(34, 82 - index * 12)}</b></button>`).join("")
    : `<div class="empty-state">No weak topics generated yet.</div>`;

  const tasks = artifacts.planner || [];
  $$(".day-column").forEach((column, index) => {
    $$(".plan-task", column).forEach(task => task.remove());
    $(".empty-state", column)?.remove();
    const task = tasks[index];
    column.insertAdjacentHTML("beforeend", task
      ? `<div class="plan-task" draggable="true"><span>${escapeHtml(task.label || task.subject || "AI task")}</span>${escapeHtml(task.task || task.title || "Review generated material")}<small>${escapeHtml(task.duration || "30 min")}</small></div>`
      : `<div class="empty-state">No task generated.</div>`);
  });

  $("#trackerStatus").textContent = "AI generated";
  $("#velocityStatus").textContent = "AI generated";
  $("#readinessRing").style.setProperty("--value", artifacts.readiness || 22);
  $("#readinessValue").textContent = `${artifacts.readiness || 22}%`;
  $("#readinessCopy").textContent = "AI baseline generated from the uploaded content.";
  $("#floatWeak").textContent = topics[0] || "Generated study set";
  $("#floatTask").textContent = tasks[0]?.task || "Review study set";
  renderHeatmap();
  $("#trendEmpty").classList.add("hidden");
  $("#trendChart").classList.remove("hidden");
  setupPlannerDrag();
  saveWorkspace();
}

async function generateAiStudySet() {
  if (!uploadedSources.length) {
    showToast("Upload a file first.");
    return;
  }
  if (!apiKey) {
    showToast("Add a Gemini API key to generate AI quiz, flashcards, and planner.");
    return;
  }
  $("#aiStatus").textContent = "Generating study set";
  showToast("Generating AI quiz, flashcards, summaries, and planner...");
  const instruction = `Analyze the uploaded study material and return ONLY valid JSON with this schema:
{
  "summaries": {
    "keyConcepts": ["3-5 concise concepts from the content"],
    "formulas": ["important formulas/facts, or empty if none"]
  },
  "quiz": [
    {"question":"content-specific MCQ", "options":["A","B","C","D"], "answerIndex":0}
  ],
  "flashcards": [
    {"front":"content-specific prompt", "back":"answer from material"}
  ],
  "weakTopics": ["topics a student should review"],
  "planner": [
    {"label":"topic", "task":"specific study task", "duration":"25 min"}
  ],
  "readiness": 15
}
Make every item specific to the uploaded material. Do not use generic filename-based questions. Generate 6 quiz questions, 6 flashcards, 4 weak topics, and 3 planner tasks.`;
  try {
    const artifacts = await requestGeminiJson(instruction);
    applyStudyArtifacts(artifacts);
    $("#aiStatus").textContent = "Gemini ready";
    showToast("AI study set generated.");
  } catch (error) {
    $("#aiStatus").textContent = "Gemini ready";
    showToast(error.message);
  }
}

async function streamAiResponse(prompt) {
  const typing = addMessage("ai", '<span class="typing"><span></span><span></span><span></span></span>');
  let response;
  try {
    const aiResponse = await callGemini(prompt);
    response = aiResponse
      ? `<strong>AI answer from your upload</strong><p>${markdownToHtml(aiResponse)}</p>`
      : buildAiResponse(prompt);
  } catch (error) {
    response = `<strong>Gemini could not answer.</strong><p>${escapeHtml(error.message)}</p><p>Check your API key/model name, then try again. I will use local text matching until the API is working.</p>${buildAiResponse(prompt)}`;
  }
  const streamText = response.replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim();
  let cursor = 0;

  setTimeout(() => {
    typing.innerHTML = "";
    const timer = setInterval(() => {
      cursor += 3;
      typing.textContent = streamText.slice(0, cursor);
      $("#messages").scrollTop = $("#messages").scrollHeight;
      if (cursor >= streamText.length) {
        clearInterval(timer);
        typing.innerHTML = response;
      }
    }, 18);
  }, 700);
}

function topTermsFromUploads(limit = 6) {
  const stop = new Set(["this", "that", "with", "from", "have", "were", "which", "their", "there", "using", "into", "about", "will", "study", "notes"]);
  const counts = new Map();
  getReadableSources().forEach(source => {
    tokenize(source.text).forEach(word => {
      if (!stop.has(word)) counts.set(word, (counts.get(word) || 0) + 1);
    });
  });
  return [...counts.entries()].sort((a, b) => b[1] - a[1]).slice(0, limit).map(([word]) => word);
}

function fallbackTermsFromFiles(limit = 6) {
  const fromText = topTermsFromUploads(limit);
  if (fromText.length) return fromText;
  return uploadedSources
    .flatMap(source => source.name.replace(/\.[^.]+$/, "").split(/[^a-z0-9]+/i))
    .filter(word => word.length > 2)
    .slice(0, limit);
}

function primarySourceName() {
  return uploadedSources[0]?.name || "your upload";
}

function hydrateWorkspaceFromUploads() {
  const readable = getReadableSources();
  const terms = fallbackTermsFromFiles();
  const sourceCount = uploadedSources.length;
  const charCount = readable.reduce((total, source) => total + source.text.length, 0);
  const hasUploads = sourceCount > 0;
  const primaryName = primarySourceName();

  $("#coreSourceCount").textContent = `${sourceCount} source${sourceCount === 1 ? "" : "s"} uploaded`;
  $("#coreTokenCount").textContent = readable.length ? `${Math.max(0, Math.round(charCount / 4)).toLocaleString()} tokens indexed` : "AI attachment ready";
  $("#sidebarInsight").textContent = readable.length
    ? "Readable notes indexed. Features are seeded from your upload."
    : "File attached. Gemini will read it when you ask questions.";
  $("#velocityStatus").textContent = hasUploads ? "Started" : "No data";
  $("#velocityChart").innerHTML = hasUploads
    ? `<span style="--h:34%"></span><span style="--h:48%"></span><span style="--h:42%"></span><span style="--h:66%"></span><span style="--h:58%"></span><span style="--h:74%"></span><span style="--h:62%"></span>`
    : `<div class="empty-state">No productivity data yet.</div>`;
  $("#readinessRing").style.setProperty("--value", hasUploads ? 12 : 0);
  $("#readinessValue").textContent = hasUploads ? "12%" : "0%";
  $("#readinessCopy").textContent = hasUploads
    ? "Starter baseline created. Quiz performance will improve this estimate."
    : "Upload notes to estimate readiness.";
  $("#floatWeak").textContent = terms[0] || "Waiting for quiz data";
  $("#floatTask").textContent = hasUploads ? "Generate summary" : "Upload notes";

  $("#sprintTasks").innerHTML = hasUploads
    ? `<li><span></span> Summarize ${escapeHtml(primaryName)}</li><li><span></span> Generate 5 questions</li><li><span></span> Create flashcards</li>`
    : `<li><span></span> Upload a note to generate tasks</li>`;

  const snippets = readable.length ? chunkText(readable[0].text, 260) : [];
  if (hasUploads) {
    $$(".summary-card p")[0].textContent = snippets[0] || `Ask "summarize ${primaryName}" to generate a clean AI summary.`;
    $$(".summary-card p")[1].textContent = readable[0]?.text.split(/\r?\n/).find(line => /[=+\-*/^]|formula|equation|where/i.test(line)) || "Ask for formulas to extract them from the upload.";
    $$(".summary-card p")[2].textContent = snippets[0]
      ? `Front: What is the main idea of ${readable[0].name}? Back: ${snippets[0].slice(0, 160)}`
      : `Front: What is ${primaryName} about? Back: Ask Astra after Gemini reads it.`;
  }

  const quizTerms = terms.length ? terms : ["main idea", "key terms", "evidence", "conclusion"];
  quiz = hasUploads ? quizTerms.slice(0, 4).map((term, index) => ({
    q: `Which option should you review from ${primaryName}?`,
    options: [term, quizTerms[index + 1] || "supporting detail", "unrelated topic", "skip"],
    answer: 0
  })) : [];
  quizIndex = 0;
  renderQuiz();

  $("#flashDue").textContent = hasUploads ? "Generated" : "Waiting";
  $("#flashFront").textContent = terms[0] ? `What does "${terms[0]}" mean in your upload?` : `What is ${primaryName} mainly about?`;
  $("#flashBack").textContent = snippets[0]?.slice(0, 180) || "Ask Astra for the answer after Gemini reads the file.";

  $("#topicList").innerHTML = terms.length
    ? terms.slice(0, 3).map((term, index) => `<button><span style="--w:${72 - index * 14}%"></span> ${escapeHtml(term)} <b>${72 - index * 14}</b></button>`).join("")
    : `<div class="empty-state">${hasUploads ? "Starter tracker active. Quiz results will reveal weak topics." : "No weak topics yet. Generate a quiz from your upload first."}</div>`;
  if (hasUploads) renderHeatmap();
  $("#trackerStatus").textContent = hasUploads ? "Baseline created" : "No data yet";
  $("#trendEmpty").classList.toggle("hidden", hasUploads);
  $("#trendChart").classList.toggle("hidden", !hasUploads);

  $$(".day-column").forEach((column, index) => {
    $$(".plan-task", column).forEach(task => task.remove());
    $(".empty-state", column)?.remove();
    if (hasUploads) {
      const label = terms[index] || ["summary", "quiz", "flashcards"][index] || "review";
      column.insertAdjacentHTML("beforeend", `<div class="plan-task" draggable="true"><span>${escapeHtml(label)}</span>Review ${escapeHtml(primaryName)}<small>${25 + index * 10} min</small></div>`);
    } else {
      column.insertAdjacentHTML("beforeend", `<div class="empty-state">No tasks yet.</div>`);
    }
  });
  setupPlannerDrag();
}

function setupAmbientCanvas() {
  const canvas = $("#ambient-canvas");
  const ctx = canvas.getContext("2d");
  const particles = Array.from({ length: 90 }, () => ({
    x: Math.random(),
    y: Math.random(),
    r: Math.random() * 1.8 + 0.4,
    vx: (Math.random() - 0.5) * 0.0008,
    vy: (Math.random() - 0.5) * 0.0008,
    hue: Math.random() > 0.55 ? 186 : 152
  }));

  function resize() {
    canvas.width = innerWidth * devicePixelRatio;
    canvas.height = innerHeight * devicePixelRatio;
  }

  function draw() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.globalCompositeOperation = "lighter";
    particles.forEach(particle => {
      particle.x += particle.vx;
      particle.y += particle.vy;
      if (particle.x < 0 || particle.x > 1) particle.vx *= -1;
      if (particle.y < 0 || particle.y > 1) particle.vy *= -1;
      const x = particle.x * canvas.width;
      const y = particle.y * canvas.height;
      const gradient = ctx.createRadialGradient(x, y, 0, x, y, particle.r * 18);
      gradient.addColorStop(0, `hsla(${particle.hue}, 95%, 70%, .28)`);
      gradient.addColorStop(1, `hsla(${particle.hue}, 95%, 70%, 0)`);
      ctx.fillStyle = gradient;
      ctx.beginPath();
      ctx.arc(x, y, particle.r * 18, 0, Math.PI * 2);
      ctx.fill();
    });
    requestAnimationFrame(draw);
  }

  addEventListener("resize", resize);
  resize();
  draw();
}

function setupUploads() {
  const dropzone = $("#dropzone");
  const fileInput = $("#fileInput");
  const fileStack = $("#fileStack");
  const readableTypes = ["text/", "application/json", "application/xml", "application/javascript"];
  const readableExtensions = [".txt", ".md", ".csv", ".json", ".xml", ".js", ".ts", ".py", ".html", ".css"];

  function canReadAsText(file) {
    const lowerName = file.name.toLowerCase();
    return readableTypes.some(type => file.type.startsWith(type)) || readableExtensions.some(ext => lowerName.endsWith(ext));
  }

  function readTextFile(file) {
    return new Promise(resolve => {
      if (!canReadAsText(file)) {
        resolve("");
        return;
      }
      if (file.name.toLowerCase().endsWith(".pdf")) {
        resolve("");
        return;
      }
      const reader = new FileReader();
      reader.onload = () => resolve(String(reader.result || ""));
      reader.onerror = () => resolve("");
      reader.readAsText(file);
    });
  }

  async function addFiles(files) {
    const incoming = [...files];
    if (!incoming.length) return;
    fileStack.classList.remove("empty");
    $(".empty-state", fileStack)?.remove();

    for (const file of incoming) {
      const ext = file.name.split(".").pop().slice(0, 3).toUpperCase();
      const chip = document.createElement("div");
      chip.className = "file-chip";
      chip.innerHTML = `<span>${ext}</span>${escapeHtml(file.name)}<small>Reading</small>`;
      fileStack.prepend(chip);

      const text = await readTextFile(file);
      const base64 = await fileToBase64(file);
      uploadedSources = uploadedSources.filter(source => source.name !== file.name);
      uploadedSources.push({ name: file.name, type: file.type || "application/octet-stream", text, base64 });
      $("small", chip).textContent = text ? `${Math.round(text.length / 1000)}k chars indexed` : "Needs Gemini";
      chip.classList.toggle("unreadable", !text);
      chip.animate([{ transform: "scale(.98)" }, { transform: "scale(1)" }], { duration: 360, easing: "cubic-bezier(.2,.8,.2,1)" });
    }

    const readableCount = incoming.filter(file => canReadAsText(file)).length;
    hydrateWorkspaceFromUploads();
    saveWorkspace();
    showToast(readableCount ? `${readableCount} text source${readableCount > 1 ? "s" : ""} indexed locally.` : "File attached. Add a Gemini key for PDF/image understanding.");
    if (apiKey) generateAiStudySet();
  }

  ["dragenter", "dragover"].forEach(eventName => {
    dropzone.addEventListener(eventName, event => {
      event.preventDefault();
      dropzone.classList.add("dragging");
    });
  });

  ["dragleave", "drop"].forEach(eventName => {
    dropzone.addEventListener(eventName, event => {
      event.preventDefault();
      dropzone.classList.remove("dragging");
    });
  });

  dropzone.addEventListener("drop", event => addFiles(event.dataTransfer.files));
  fileInput.addEventListener("change", event => addFiles(event.target.files));
}

function setupPlannerDrag() {
  let dragged = null;
  $$(".plan-task").forEach(task => {
    task.addEventListener("dragstart", () => {
      dragged = task;
      task.classList.add("dragging");
    });
    task.addEventListener("dragend", () => task.classList.remove("dragging"));
  });

  $$(".day-column").forEach(column => {
    column.addEventListener("dragover", event => {
      event.preventDefault();
      column.classList.add("drag-over");
    });
    column.addEventListener("dragleave", () => column.classList.remove("drag-over"));
    column.addEventListener("drop", () => {
      column.classList.remove("drag-over");
      if (dragged) column.appendChild(dragged);
      showToast("Task moved. Astra recalculated the revision timeline.");
    });
  });
}

function setupHeatmap() {
  const heatmap = $("#heatmap");
  heatmap.innerHTML = '<div class="empty-state">No consistency data yet.</div>';
}

function renderHeatmap() {
  const heatmap = $("#heatmap");
  heatmap.innerHTML = "";
  for (let i = 0; i < 50; i += 1) {
    const cell = document.createElement("span");
    const intensity = Math.random();
    cell.style.background = `rgba(${Math.round(103 + intensity * 39)}, ${Math.round(160 + intensity * 87)}, ${Math.round(249 - intensity * 50)}, ${0.12 + intensity * 0.58})`;
    cell.title = `${Math.round(intensity * 100)}% consistency`;
    heatmap.appendChild(cell);
  }
}

function setupMagneticButtons() {
  $$(".magnetic").forEach(button => {
    button.addEventListener("mousemove", event => {
      const rect = button.getBoundingClientRect();
      const x = (event.clientX - rect.left - rect.width / 2) * 0.18;
      const y = (event.clientY - rect.top - rect.height / 2) * 0.18;
      button.style.transform = `translate(${x}px, ${y}px)`;
    });
    button.addEventListener("mouseleave", () => {
      button.style.transform = "";
    });
  });
}

function setupParallax() {
  const cards = $$(".float-card, .ai-core");
  addEventListener("pointermove", event => {
    const x = (event.clientX / innerWidth - 0.5) * 18;
    const y = (event.clientY / innerHeight - 0.5) * 18;
    cards.forEach((card, index) => {
      card.style.translate = `${x * (index + 1) * 0.2}px ${y * (index + 1) * 0.2}px`;
    });
  });
}

function setupSummaries() {
  $("#summaryModes").addEventListener("click", event => {
    const button = event.target.closest("button");
    if (!button) return;
    $$("#summaryModes button").forEach(item => item.classList.toggle("active", item === button));
    $$(".summary-card").forEach((card, index) => {
      $("p", card).textContent = summaryContent[button.dataset.mode][index];
      card.animate([{ transform: "translateY(10px)", opacity: 0.3 }, { transform: "translateY(0)", opacity: 1 }], { duration: 360, easing: "cubic-bezier(.2,.8,.2,1)" });
    });
  });

  $("#summaryGrid").addEventListener("click", event => {
    const toggle = event.target.closest(".summary-toggle");
    if (!toggle) return;
    const card = toggle.closest(".summary-card");
    card.classList.toggle("expanded");
    $("span", toggle).textContent = card.classList.contains("expanded") ? "-" : "+";
  });
}

function setupApiSettings() {
  const keyInput = $("#apiKeyInput");
  const modelInput = $("#modelInput");
  if (!keyInput || !modelInput) return;
  keyInput.value = apiKey;
  modelInput.value = apiModel;
  $("#aiStatus").textContent = apiKey ? "Gemini ready" : "Local mode";

  $("#saveApiKey").addEventListener("click", () => {
    apiKey = keyInput.value.trim();
    apiModel = modelInput.value.trim() || "gemini-2.5-flash";
    if (apiKey) {
      localStorage.setItem("astraGeminiKey", apiKey);
    } else {
      localStorage.removeItem("astraGeminiKey");
    }
    localStorage.setItem("astraGeminiModel", apiModel);
    $("#aiStatus").textContent = apiKey ? "Gemini ready" : "Local mode";
    saveWorkspace();
    showToast(apiKey ? "Gemini API key saved for this browser." : "API key cleared. Using local mode.");
    if (apiKey && uploadedSources.length) generateAiStudySet();
  });

  $("#generateStudySet").addEventListener("click", generateAiStudySet);
}

function setupAuth() {
  const savedClientId = localStorage.getItem("astraGoogleClientId") || "";
  $("#googleClientId").value = savedClientId;
  if (currentUser) setCurrentUser(currentUser);

  $("#googleLogin").addEventListener("click", async () => {
    const clientId = $("#googleClientId").value.trim();
    if (!clientId) {
      showToast("Paste a Google OAuth Client ID, or use Gmail locally.");
      return;
    }
    localStorage.setItem("astraGoogleClientId", clientId);
    try {
      await loadGoogleScript();
      google.accounts.id.initialize({
        client_id: clientId,
        callback: response => {
          const profile = decodeJwtPayload(response.credential);
          setCurrentUser({
            name: profile.name,
            email: profile.email,
            picture: profile.picture,
            provider: "google"
          });
          showToast("Signed in with Google.");
        }
      });
      google.accounts.id.renderButton($("#googleButton"), {
        theme: "outline",
        size: "large",
        shape: "rectangular",
        text: "continue_with"
      });
      google.accounts.id.prompt();
    } catch {
      showToast("Could not load Google login. Check network or use local Gmail mode.");
    }
  });

  $("#localLogin").addEventListener("click", () => {
    const email = $("#localEmail").value.trim();
    if (!email || !email.includes("@")) {
      showToast("Enter a Gmail address for the local profile.");
      return;
    }
    setCurrentUser({
      name: email.split("@")[0],
      email,
      provider: "local-google"
    });
    showToast("Local profile created.");
  });

  $("#signOut").addEventListener("click", () => {
    saveWorkspace();
    localStorage.removeItem("astraCurrentUser");
    currentUser = null;
    $("#authScreen").classList.remove("hidden");
    $("#profilePill").classList.add("hidden");
    showToast("Signed out.");
  });
}

function setupSolver() {
  $("#solveDoubt").addEventListener("click", () => {
    const input = $("#doubtInput").value.trim() || "this doubt";
    const steps = [
      `Identify the exact concept in: "${input.slice(0, 58)}${input.length > 58 ? "..." : ""}"`,
      "Break the problem into known facts, target result, and the missing bridge.",
      "Solve one small step at a time, then check the answer against intuition."
    ];
    $$(".step").forEach((step, index) => {
      $("p", step).textContent = steps[index];
      step.classList.remove("active");
      setTimeout(() => step.classList.add("active"), index * 280);
    });
    showToast("Doubt solver generated a guided explanation.");
  });
}

function setupEvents() {
  addEventListener("scroll", () => {
    updateScrollProgress();
    setActiveNav();
    revealOnScroll();
  }, { passive: true });

  $$("[data-jump]").forEach(button => {
    button.addEventListener("click", () => $(`#${button.dataset.jump}`).scrollIntoView({ behavior: "smooth" }));
  });

  $$("[data-open-chat]").forEach(button => {
    button.addEventListener("click", () => $("#upload").scrollIntoView({ behavior: "smooth" }));
  });

  $("#themeToggle").addEventListener("click", () => {
    document.body.classList.toggle("light");
    showToast(document.body.classList.contains("light") ? "Light mode enabled." : "Dark mode enabled.");
  });

  $("#answers").addEventListener("click", event => {
    const button = event.target.closest("button");
    if (button) selectAnswer(button);
  });

  $("#nextQuestion").addEventListener("click", () => {
    if (!quiz.length) {
      showToast("Upload readable notes or ask Gemini to generate quiz content first.");
      return;
    }
    quizIndex = (quizIndex + 1) % quiz.length;
    renderQuiz();
  });

  $("#flashcard").addEventListener("click", () => $("#flashcard").classList.toggle("flipped"));
  $("#flashcard").addEventListener("keydown", event => {
    if (event.key === "Enter" || event.key === " ") $("#flashcard").classList.toggle("flipped");
  });
  $("#hardCard").addEventListener("click", () => showToast("Card rescheduled sooner for spaced repetition."));
  $("#knowCard").addEventListener("click", () => showToast("Nice. Card moved to a longer interval."));

  $("#chatForm").addEventListener("submit", event => {
    event.preventDefault();
    const input = $("#chatInput");
    const value = input.value.trim();
    if (!value) return;
    $(".empty-chat")?.remove();
    addMessage("user", escapeHtml(value));
    input.value = "";
    streamAiResponse(value);
  });

  $("#suggestions").addEventListener("click", event => {
    const button = event.target.closest("button");
    if (!button) return;
    $("#chatInput").value = button.textContent;
    $("#chatForm").requestSubmit();
  });

  $("#rebalancePlan").addEventListener("click", () => {
    const column = $$(".day-column")[1];
    const task = document.createElement("div");
    task.className = "plan-task";
    task.draggable = true;
    const term = topTermsFromUploads(1)[0] || "Uploaded notes";
    task.innerHTML = `<span>AI Priority</span>Review ${escapeHtml(term)}<small>30 min</small>`;
    column.appendChild(task);
    setupPlannerDrag();
    showToast("Plan adapted around your missed session.");
  });
}

setupAmbientCanvas();
setupAuth();
setupUploads();
setupApiSettings();
setupHeatmap();
setupPlannerDrag();
setupMagneticButtons();
setupParallax();
setupSummaries();
setupSolver();
setupEvents();
renderQuiz();
updateScrollProgress();
revealOnScroll();
